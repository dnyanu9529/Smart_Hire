import os

class Config:
    SQLALCHEMY_DATABASE_URI = "postgresql://postgres:admin%409529@localhost:5432/smarthire"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = "smarthire_secret_key"