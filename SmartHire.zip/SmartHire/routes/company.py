from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_required, current_user
from models import db, Job, CompanyProfile, Application, UserProfile

company_bp = Blueprint('company', __name__)


def get_or_create_profile():
    profile = CompanyProfile.query.filter_by(user_id=current_user.id).first()
    if not profile:
        profile = CompanyProfile(user_id=current_user.id)
        db.session.add(profile)
        db.session.commit()
    return profile


@company_bp.route('/company')
@login_required
def company_dashboard():
    if current_user.role != "company":
        return "Access Denied"

    jobs = Job.query.filter_by(company_id=current_user.id).all()
    total_jobs = len(jobs)
    job_ids = [j.id for j in jobs]
    total_applications = Application.query.filter(Application.job_id.in_(job_ids)).count() if job_ids else 0
    profile = get_or_create_profile()

    return render_template("company_dashboard.html",
                           total_jobs=total_jobs,
                           total_applications=total_applications,
                           jobs=jobs,
                           profile=profile)


@company_bp.route('/company/profile', methods=['GET', 'POST'])
@login_required
def company_profile():
    if current_user.role != "company":
        return "Access Denied"

    profile = get_or_create_profile()

    if request.method == 'POST':
        profile.company_name  = request.form.get('company_name')
        profile.industry      = request.form.get('industry')
        profile.location      = request.form.get('location')
        profile.website       = request.form.get('website')
        profile.phone         = request.form.get('phone')
        profile.description   = request.form.get('description')
        profile.founded_year  = request.form.get('founded_year')
        profile.employee_count = request.form.get('employee_count')

        db.session.commit()
        flash("Profile updated successfully!")
        return redirect(url_for('company.company_profile'))

    return render_template("company_profile.html", profile=profile)


@company_bp.route('/post_job', methods=['GET', 'POST'])
@login_required
def post_job():
    if current_user.role != "company":
        return "Access Denied"

    if request.method == 'POST':
        new_job = Job(
            title=request.form.get('title'),
            description=request.form.get('description'),
            salary=request.form.get('salary'),
            job_type=request.form.get('job_type'),
            location=request.form.get('location'),
            experience=request.form.get('experience'),
            skills=request.form.get('skills'),
            company_id=current_user.id
        )
        db.session.add(new_job)
        db.session.commit()
        flash("Job posted successfully!")
        return redirect(url_for('company.company_dashboard'))

    profile = get_or_create_profile()
    return render_template("post_job.html", profile=profile)


@company_bp.route('/company/applications')
@login_required
def company_applications():
    if current_user.role != "company":
        return "Access Denied"

    profile = get_or_create_profile()
    job_filter = request.args.get('job_id', 'all')
    status_filter = request.args.get('status', 'all')

    jobs = Job.query.filter_by(company_id=current_user.id).all()
    job_ids = [j.id for j in jobs]

    query = Application.query.filter(Application.job_id.in_(job_ids)) if job_ids else Application.query.filter_by(id=None)

    if job_filter != 'all':
        query = query.filter_by(job_id=int(job_filter))
    if status_filter != 'all':
        query = query.filter_by(status=status_filter)

    applications = query.order_by(Application.applied_on.desc()).all()

    total    = Application.query.filter(Application.job_id.in_(job_ids)).count() if job_ids else 0
    pending  = Application.query.filter(Application.job_id.in_(job_ids), Application.status=='pending').count() if job_ids else 0
    accepted = Application.query.filter(Application.job_id.in_(job_ids), Application.status=='accepted').count() if job_ids else 0
    rejected = Application.query.filter(Application.job_id.in_(job_ids), Application.status=='rejected').count() if job_ids else 0

    return render_template("company_applications.html",
                           applications=applications,
                           jobs=jobs,
                           profile=profile,
                           job_filter=job_filter,
                           status_filter=status_filter,
                           total=total,
                           pending=pending,
                           accepted=accepted,
                           rejected=rejected)


@company_bp.route('/company/application/<int:app_id>/<action>')
@login_required
def update_application(app_id, action):
    if current_user.role != "company":
        return "Access Denied"

    application = Application.query.get_or_404(app_id)

    # make sure this application belongs to this company's job
    job = Job.query.get(application.job_id)
    if job.company_id != current_user.id:
        return "Access Denied"

    if action == 'accept':
        application.status = 'accepted'
        flash("Application accepted!")
    elif action == 'reject':
        application.status = 'rejected'
        flash("Application rejected.")

    db.session.commit()
    return redirect(url_for('company.company_applications'))