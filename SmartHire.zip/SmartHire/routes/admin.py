from flask import Blueprint, render_template, jsonify, make_response, redirect, url_for, flash, request
from flask_login import login_required, current_user
from models import db, User, Job, Application
from datetime import datetime, timedelta

admin_bp = Blueprint('admin', __name__)


def get_report_data(period='weekly'):
    now = datetime.utcnow()
    if period == 'weekly':
        labels = [(now - timedelta(days=i)).strftime('%a') for i in range(6, -1, -1)]
    elif period == 'monthly':
        labels = [(now - timedelta(days=i*3)).strftime('%d %b') for i in range(9, -1, -1)]
    else:
        labels = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

    total_users        = User.query.filter_by(role='user').count()
    total_companies    = User.query.filter_by(role='company').count()
    total_jobs         = Job.query.count()
    total_applications = Application.query.count()
    pending  = Application.query.filter_by(status='pending').count()
    accepted = Application.query.filter_by(status='accepted').count()
    rejected = Application.query.filter_by(status='rejected').count()
    total_app = pending + accepted + rejected

    company_stats = []
    for c in User.query.filter_by(role='company').all():
        company_stats.append({'name': c.username, 'jobs': Job.query.filter_by(company_id=c.id).count()})
    company_stats.sort(key=lambda x: x['jobs'], reverse=True)

    job_stats = []
    for j in Job.query.all():
        job_stats.append({'title': j.title, 'apps': Application.query.filter_by(job_id=j.id).count()})
    job_stats.sort(key=lambda x: x['apps'], reverse=True)

    return {
        'period': period,
        'labels': labels,
        'total_users': total_users,
        'total_companies': total_companies,
        'total_jobs': total_jobs,
        'total_applications': total_applications,
        'new_users': total_users,
        'new_companies': total_companies,
        'new_jobs': total_jobs,
        'new_apps': total_applications,
        'pending': pending,
        'accepted': accepted,
        'rejected': rejected,
        'pending_pct':  round((pending  / total_app * 100) if total_app else 0),
        'accepted_pct': round((accepted / total_app * 100) if total_app else 0),
        'rejected_pct': round((rejected / total_app * 100) if total_app else 0),
        'company_stats': company_stats[:5],
        'job_stats': job_stats[:5],
        'generated_at': now.strftime('%d %B %Y, %I:%M %p'),
    }


@admin_bp.route('/admin')
@login_required
def admin_dashboard():
    if current_user.role != "admin":
        return "Access Denied"
    total_users     = User.query.filter_by(role='user').count()
    total_companies = User.query.filter_by(role='company').count()
    total_admins    = User.query.filter_by(role='admin').count()
    return render_template("admin_dashboard.html",
                           total_users=total_users,
                           total_companies=total_companies,
                           total_admins=total_admins)


@admin_bp.route('/admin/reports')
@admin_bp.route('/admin/reports/<period>')
@login_required
def admin_reports(period='weekly'):
    if current_user.role != "admin":
        return "Access Denied"
    if period not in ['weekly', 'monthly', 'yearly']:
        period = 'weekly'
    return render_template("admin_reports.html", **get_report_data(period))


@admin_bp.route('/admin/reports/<period>/download')
@login_required
def download_report(period='weekly'):
    if current_user.role != "admin":
        return "Access Denied"
    data = get_report_data(period)
    lines = [
        f"SmartHire Platform Report - {period.capitalize()}",
        f"Generated: {data['generated_at']}", "",
        "=== PLATFORM OVERVIEW ===",
        f"Total Users,{data['total_users']}",
        f"Total Companies,{data['total_companies']}",
        f"Total Jobs,{data['total_jobs']}",
        f"Total Applications,{data['total_applications']}", "",
        "=== APPLICATION STATUS ===",
        f"Pending,{data['pending']},{data['pending_pct']}%",
        f"Accepted,{data['accepted']},{data['accepted_pct']}%",
        f"Rejected,{data['rejected']},{data['rejected_pct']}%", "",
        "=== TOP COMPANIES ===", "Company,Jobs Posted",
    ]
    for c in data['company_stats']:
        lines.append(f"{c['name']},{c['jobs']}")
    lines += ["", "=== MOST APPLIED JOBS ===", "Job Title,Applications"]
    for j in data['job_stats']:
        lines.append(f"{j['title']},{j['apps']}")

    response = make_response("\n".join(lines))
    response.headers["Content-Disposition"] = f"attachment; filename=smarthire_report_{period}_{datetime.utcnow().strftime('%Y%m%d')}.csv"
    response.headers["Content-Type"] = "text/csv"
    return response


# ─── Manage Users ────────────────────────────────────────────
@admin_bp.route('/admin/users')
@login_required
def manage_users():
    if current_user.role != "admin":
        return "Access Denied"

    role_filter = request.args.get('role', 'all')
    search      = request.args.get('search', '').strip()

    query = User.query
    if role_filter != 'all':
        query = query.filter_by(role=role_filter)
    if search:
        query = query.filter(
            (User.username.ilike(f'%{search}%')) |
            (User.email.ilike(f'%{search}%'))
        )
    users = query.order_by(User.id).all()

    total_users     = User.query.filter_by(role='user').count()
    total_companies = User.query.filter_by(role='company').count()
    total_admins    = User.query.filter_by(role='admin').count()

    return render_template("admin_users.html",
                           users=users,
                           role_filter=role_filter,
                           search=search,
                           total_users=total_users,
                           total_companies=total_companies,
                           total_admins=total_admins)


@admin_bp.route('/admin/users/<int:user_id>/delete', methods=['POST'])
@login_required
def delete_user(user_id):
    if current_user.role != "admin":
        return "Access Denied"

    user = User.query.get_or_404(user_id)

    if user.role == 'admin':
        flash("Cannot delete admin accounts.", "danger")
        return redirect(url_for('admin.manage_users'))

    # delete related data first
    Application.query.filter_by(user_id=user_id).delete()
    jobs = Job.query.filter_by(company_id=user_id).all()
    for job in jobs:
        Application.query.filter_by(job_id=job.id).delete()
    Job.query.filter_by(company_id=user_id).delete()

    db.session.delete(user)
    db.session.commit()
    flash(f"User '{user.username}' deleted successfully.", "success")
    return redirect(url_for('admin.manage_users'))


# ─── Manage Jobs ─────────────────────────────────────────────
@admin_bp.route('/admin/jobs')
@login_required
def manage_jobs():
    if current_user.role != "admin":
        return "Access Denied"

    type_filter = request.args.get('type', 'all')
    search      = request.args.get('search', '').strip()

    query = Job.query
    if type_filter != 'all':
        query = query.filter_by(job_type=type_filter)
    if search:
        query = query.filter(Job.title.ilike(f'%{search}%'))
    jobs = query.order_by(Job.id.desc()).all()

    total_jobs         = Job.query.count()
    total_applications = Application.query.count()
    total_companies    = User.query.filter_by(role='company').count()

    return render_template("admin_jobs.html",
                           jobs=jobs,
                           type_filter=type_filter,
                           search=search,
                           total_jobs=total_jobs,
                           total_applications=total_applications,
                           total_companies=total_companies)


@admin_bp.route('/admin/jobs/<int:job_id>/delete', methods=['POST'])
@login_required
def delete_job(job_id):
    if current_user.role != "admin":
        return "Access Denied"

    job = Job.query.get_or_404(job_id)
    Application.query.filter_by(job_id=job_id).delete()
    db.session.delete(job)
    db.session.commit()
    flash(f"Job '{job.title}' deleted successfully.", "success")
    return redirect(url_for('admin.manage_jobs'))