from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_required, current_user
from models import db, Job, UserProfile, Application

user_bp = Blueprint('user', __name__)


def get_or_create_profile():
    profile = UserProfile.query.filter_by(user_id=current_user.id).first()
    if not profile:
        profile = UserProfile(user_id=current_user.id)
        db.session.add(profile)
        db.session.commit()
    return profile


@user_bp.route('/user')
@login_required
def user_dashboard():
    if current_user.role != "user":
        return "Access Denied"

    jobs = Job.query.all()
    total_jobs = len(jobs)
    profile = get_or_create_profile()

    # get job ids user already applied to
    applied_job_ids = [a.job_id for a in Application.query.filter_by(user_id=current_user.id).all()]

    return render_template("user_dashboard.html",
                           jobs=jobs,
                           total_jobs=total_jobs,
                           profile=profile,
                           applied_job_ids=applied_job_ids)


@user_bp.route('/apply/<int:job_id>', methods=['POST'])
@login_required
def apply_job(job_id):
    if current_user.role != "user":
        return "Access Denied"

    profile = get_or_create_profile()

    if not profile.can_apply():
        flash("Please complete your profile before applying.")
        return redirect(url_for('user.user_profile'))

    # check already applied
    existing = Application.query.filter_by(job_id=job_id, user_id=current_user.id).first()
    if existing:
        flash("You have already applied for this job.")
        return redirect(url_for('user.user_dashboard'))

    application = Application(job_id=job_id, user_id=current_user.id)
    db.session.add(application)
    db.session.commit()

    flash("Application submitted successfully!")
    return redirect(url_for('user.user_dashboard'))


@user_bp.route('/user/applications')
@login_required
def my_applications():
    if current_user.role != "user":
        return "Access Denied"

    profile = get_or_create_profile()
    status_filter = request.args.get('status', 'all')

    query = Application.query.filter_by(user_id=current_user.id)
    if status_filter != 'all':
        query = query.filter_by(status=status_filter)

    applications = query.order_by(Application.applied_on.desc()).all()

    total       = Application.query.filter_by(user_id=current_user.id).count()
    pending     = Application.query.filter_by(user_id=current_user.id, status='pending').count()
    accepted    = Application.query.filter_by(user_id=current_user.id, status='accepted').count()
    rejected    = Application.query.filter_by(user_id=current_user.id, status='rejected').count()

    return render_template("my_applications.html",
                           applications=applications,
                           profile=profile,
                           status_filter=status_filter,
                           total=total,
                           pending=pending,
                           accepted=accepted,
                           rejected=rejected)


@user_bp.route('/user/profile', methods=['GET', 'POST'])
@login_required
def user_profile():
    if current_user.role != "user":
        return "Access Denied"

    profile = get_or_create_profile()

    if request.method == 'POST':
        profile.full_name    = request.form.get('full_name')
        profile.phone        = request.form.get('phone')
        profile.city         = request.form.get('city')
        profile.dob          = request.form.get('dob')
        profile.degree       = request.form.get('degree')
        profile.college      = request.form.get('college')
        profile.passout_year = request.form.get('passout_year')
        profile.percentage   = request.form.get('percentage')
        profile.skills       = request.form.get('skills')
        profile.about        = request.form.get('about')

        db.session.commit()
        flash("Profile updated successfully!")
        return redirect(url_for('user.user_profile'))

    return render_template("user_profile.html", profile=profile)