from flask import Flask, render_template, request, flash, redirect, url_for
from extensions import db, login_manager
from models import User
from routes.auth import auth_bp
from routes.admin import admin_bp
from routes.company import company_bp
from routes.user import user_bp

app = Flask(__name__)

# Config
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:admin%409529@localhost:5432/smarthire'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db.init_app(app)
login_manager.init_app(app)

# User loader
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Register blueprints
app.register_blueprint(auth_bp)
app.register_blueprint(admin_bp)
app.register_blueprint(company_bp)
app.register_blueprint(user_bp)

# ── Static / Public Routes ─────────────────────────────────────────────────────
@app.route('/')
def home():
    return render_template("home.html")

@app.route('/about')
def about():
    return render_template("about.html")

@app.route('/privacy')
def privacy():
    return render_template("privacy.html")

@app.route('/terms')
def terms():
    return render_template("terms.html")

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name    = request.form.get('name')
        email   = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')
        flash(f"Thank you {name}! We received your message and will reply to {email} within 48 hours.", "success")
        return redirect(url_for('contact'))
    return render_template("contact.html")

# ── Create DB + Default Admin ──────────────────────────────────────────────────
with app.app_context():
    db.create_all()
    if not User.query.filter_by(role='admin').first():
        admin = User(username="admin", email="admin@gmail.com", role="admin")
        admin.set_password("admin123")
        db.session.add(admin)
        db.session.commit()
        print("Admin Created Successfully!")

if __name__ == "__main__":
    app.run(debug=True,port=5001)