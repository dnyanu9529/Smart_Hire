from extensions import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(50), nullable=False)  # 'admin', 'company', 'user'
    userprofile = db.relationship('UserProfile', foreign_keys='UserProfile.user_id', uselist=False, lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class CompanyProfile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), unique=True, nullable=False)

    company_name = db.Column(db.String(200))
    industry = db.Column(db.String(100))
    location = db.Column(db.String(150))
    website = db.Column(db.String(200))
    phone = db.Column(db.String(20))
    description = db.Column(db.Text)
    founded_year = db.Column(db.String(10))
    employee_count = db.Column(db.String(50))

    def progress(self):
        fields = [
            self.company_name, self.industry, self.location,
            self.website, self.phone, self.description,
            self.founded_year, self.employee_count
        ]
        filled = sum(1 for f in fields if f and str(f).strip() != '')
        # Base 10% for just registering + rest split across 8 fields
        return 10 + int((filled / len(fields)) * 90)


class Job(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    salary = db.Column(db.String(100))
    job_type = db.Column(db.String(50))
    location = db.Column(db.String(150))
    experience = db.Column(db.String(50))
    skills = db.Column(db.String(300))
    company_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    company = db.relationship('User', foreign_keys=[company_id])
    applications = db.relationship('Application', foreign_keys='Application.job_id', lazy=True)


class UserProfile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), unique=True, nullable=False)

    full_name = db.Column(db.String(200))
    phone = db.Column(db.String(20))
    city = db.Column(db.String(100))
    dob = db.Column(db.String(20))

    degree = db.Column(db.String(100))
    college = db.Column(db.String(200))
    passout_year = db.Column(db.String(10))
    percentage = db.Column(db.String(20))

    skills = db.Column(db.String(300))
    about = db.Column(db.Text)

    def progress(self):
        fields = [
            self.full_name, self.phone, self.city,
            self.degree, self.college, self.passout_year,
            self.skills, self.about
        ]
        filled = sum(1 for f in fields if f and str(f).strip() != '')
        return 10 + int((filled / len(fields)) * 90)

    def can_apply(self):
        required = [self.full_name, self.phone, self.city,
                    self.degree, self.college, self.passout_year,
                    self.skills, self.about]
        return all(f and str(f).strip() != '' for f in required)


class Application(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    job_id = db.Column(db.Integer, db.ForeignKey('job.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, accepted, rejected
    applied_on = db.Column(db.DateTime, default=db.func.now())

    job = db.relationship('Job', foreign_keys=[job_id])
    applicant = db.relationship('User', foreign_keys=[user_id])